 <button class="register-btn" onclick="window.location.href='register_form.php'">Register</button>
 <br>
<button type='button' onclick="window.location.href='read_data.php';">View Record</button>
<br>
<button type='button' onclick="window.location.href='change_password.php';">Change Password</button>