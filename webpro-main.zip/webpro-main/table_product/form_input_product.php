<h2>Add New Product</h2>
<form action="create.php" method="post">
    Product Name: <br><input type="text" name="name"><br>
    Description: <br><textarea name="desc"></textarea> <br>
    Price: <br><input type="text" name="price"><br>
    <br>
    <input type="submit" value="Add Product">
</form>